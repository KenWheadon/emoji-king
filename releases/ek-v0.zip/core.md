HTML/JS game - no canvas. Follow DRY principles.
